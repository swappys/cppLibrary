# Example Package

This is a package for calculating fine based on date provided. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.